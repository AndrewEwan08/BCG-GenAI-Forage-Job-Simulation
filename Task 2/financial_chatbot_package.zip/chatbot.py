"""
Simple financial-data chatbot prototype (Task 2).

Design note (see chatbot_documentation.md for the full rationale):
The task brief's example hardcodes one canned answer per query string, which only
works for a single company. Since Task 1 produced data for three companies across
three fiscal years, this version keeps the same "no ML, just if-elif" spirit but adds
light keyword parsing to pull out WHICH company and WHICH year the user meant, then
looks the real number up in the Task 1 dataset (financial_data.csv). If no library
call, model, or embedding is used anywhere below -- it's string matching, a dictionary
lookup, and arithmetic. That keeps it inside the "basic chatbot" scope the task asks
for while making it usable across all three companies instead of just one.
"""

import os
import pandas as pd

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "financial_data.csv")

# Fallback so the script still runs even if financial_data.csv isn't in the same folder
# (e.g. someone copies just chatbot.py out of the zip).
_FALLBACK_DATA = [
    ["Apple", 2023, 383285, 96995, 352583, 290437, 110543],
    ["Apple", 2024, 391035, 93736, 364980, 308030, 118254],
    ["Apple", 2025, 416161, 112010, 359241, 285508, 111482],
    ["Microsoft", 2023, 211915, 72361, 411976, 205753, 87582],
    ["Microsoft", 2024, 245122, 88136, 512163, 243686, 118548],
    ["Microsoft", 2025, 281724, 101832, 619003, 275524, 136162],
    ["Tesla", 2023, 96773, 14997, 106618, 43251, 13256],
    ["Tesla", 2024, 97690, 7091, 122070, 48453, 14923],
    ["Tesla", 2025, 94827, 3794, 137806, 54999, 14747],
]
_COLUMNS = ["Company", "Fiscal Year", "Total Revenue", "Net Income",
            "Total Assets", "Total Liabilities", "Operating Cash Flow"]

COMPANIES = ["Microsoft", "Tesla", "Apple"]
DEFAULT_COMPANY = "Microsoft"   # used only if the user names no company at all
DEFAULT_YEAR = 2025             # most recent year in the dataset

# Lightweight follow-up suggestions, one per query type, so the bot points the user
# toward a related figure instead of ending the exchange as a flat lookup table.
FOLLOW_UPS = {
    "revenue": "You could also ask about net income to see if profit kept pace with revenue.",
    "net_income": "You could also ask about operating cash flow to check whether that profit was backed by real cash.",
    "net_income_change": "You could also ask about operating cash flow to check whether that change was backed by real cash.",
    "assets": "You could also ask about total liabilities to see how leveraged the company is.",
    "liabilities": "You could also ask about total assets to put that figure in context.",
    "cash_flow": "You could also ask about net income to compare reported profit to actual cash generated.",
}


def load_data():
    if os.path.exists(DATA_FILE):
        return pd.read_csv(DATA_FILE)
    return pd.DataFrame(_FALLBACK_DATA, columns=_COLUMNS)


def _find_company(query_lower):
    for name in COMPANIES:
        if name.lower() in query_lower:
            return name
    return None


def _find_year(query_lower):
    for year in (2023, 2024, 2025):
        if str(year) in query_lower:
            return year
    return None


def _fmt(n):
    return f"${n:,.0f} million"


def simple_chatbot(user_query, df=None):
    """
    Matches user_query against a small set of predefined financial questions using
    plain if-elif string checks (per the task's example), then returns a response
    built from the Task 1 dataset rather than a hardcoded placeholder.
    """
    if df is None:
        df = load_data()

    query_lower = user_query.lower().strip()
    company = _find_company(query_lower) or DEFAULT_COMPANY
    year = _find_year(query_lower) or DEFAULT_YEAR
    assumed_note = ""
    if _find_company(query_lower) is None:
        assumed_note += f" (no company named, defaulting to {company})"
    if _find_year(query_lower) is None:
        assumed_note += f" (no year named, defaulting to FY{year})"

    row = df[(df["Company"] == company) & (df["Fiscal Year"] == year)]
    if row.empty:
        return f"Sorry, I don't have data for {company} in FY{year}."
    row = row.iloc[0]

    prev_row = df[(df["Company"] == company) & (df["Fiscal Year"] == year - 1)]

    # --- Predefined query 1: total revenue ---
    if "revenue" in query_lower and "growth" not in query_lower and "grown" not in query_lower:
        return (f"{company}'s total revenue in FY{year} was {_fmt(row['Total Revenue'])}."
                f"{assumed_note} {FOLLOW_UPS['revenue']}")

    # --- Predefined query 2: net income change over the last year ---
    elif "net income" in query_lower and ("chang" in query_lower or "grow" in query_lower
                                           or "increase" in query_lower or "decrease" in query_lower):
        if prev_row.empty:
            return f"I don't have FY{year - 1} data for {company} to compute the change."
        prev = prev_row.iloc[0]
        pct = (row["Net Income"] - prev["Net Income"]) / prev["Net Income"] * 100
        direction = "increased" if pct >= 0 else "decreased"
        return (f"{company}'s net income {direction} by {abs(pct):.1f}% in FY{year} "
                f"(from {_fmt(prev['Net Income'])} to {_fmt(row['Net Income'])})."
                f"{assumed_note} {FOLLOW_UPS['net_income_change']}")

    # --- Predefined query 3: net income (plain, no "change" language) ---
    elif "net income" in query_lower:
        return (f"{company}'s net income in FY{year} was {_fmt(row['Net Income'])}."
                f"{assumed_note} {FOLLOW_UPS['net_income']}")

    # --- Predefined query 4: total assets ---
    elif "total assets" in query_lower or ("assets" in query_lower and "liabilities" not in query_lower):
        return (f"{company}'s total assets in FY{year} were {_fmt(row['Total Assets'])}."
                f"{assumed_note} {FOLLOW_UPS['assets']}")

    # --- Predefined query 5: total liabilities ---
    elif "liabilities" in query_lower:
        return (f"{company}'s total liabilities in FY{year} were {_fmt(row['Total Liabilities'])}."
                f"{assumed_note} {FOLLOW_UPS['liabilities']}")

    # --- Predefined query 6: operating cash flow ---
    elif "cash flow" in query_lower or "operating cash" in query_lower:
        return (f"{company}'s cash flow from operating activities in FY{year} was "
                f"{_fmt(row['Operating Cash Flow'])}.{assumed_note} {FOLLOW_UPS['cash_flow']}")

    else:
        return ("Sorry, I can only answer questions about total revenue, net income "
                "(including year-over-year change), total assets, total liabilities, "
                "or operating cash flow, for Microsoft, Tesla, or Apple (FY2023-FY2025).")


def run_cli():
    """Command-line interactive mode, as suggested in the task brief."""
    df = load_data()
    print("Financial chatbot prototype. Ask about revenue, net income, assets, "
          "liabilities, or operating cash flow for Microsoft, Tesla, or Apple "
          "(FY2023-FY2025). Type 'quit' to exit.\n")
    while True:
        user_query = input("You: ")
        if user_query.strip().lower() in ("quit", "exit"):
            print("Bot: Goodbye.")
            break
        print("Bot:", simple_chatbot(user_query, df))


if __name__ == "__main__":
    run_cli()
