# Financial Chatbot Prototype — Documentation

## How it works

`chatbot.py` implements `simple_chatbot(user_query, df)`, which matches the user's
question against a small set of predefined query *types* using plain `if / elif`
string checks — no machine learning, no NLP library, and no external API call, in
line with the task's "basic chatbot" scope.

The one deliberate departure from the task's literal example: instead of hardcoding
one canned answer per exact query string, the function does light keyword parsing to
identify **which company** (Microsoft / Tesla / Apple) and **which fiscal year**
(2023–2025) the user meant, then looks the real figure up in the Task 1 dataset
(`financial_data.csv`). This was necessary because Task 1 produced data for three
companies across three years — a single hardcoded answer per query would only ever
be correct for one company/year combination. If the user doesn't name a company or
year, the bot defaults to Microsoft / FY2025 and says so explicitly in its response,
rather than silently guessing.

**Revision note:** after comparing against the simulation's example answer, one idea
from it was worth adopting — Section 3 of that example suggests the dialogue "suggest
related queries or follow-up for more detail." This version was added afterward: each
successful response now ends with a one-line suggestion pointing to a related metric
(e.g. a revenue answer suggests checking net income; a net income answer suggests
checking operating cash flow as a cash-quality check). This is implemented as a static
lookup table (`FOLLOW_UPS`), not a dynamic recommendation — it's the same "no ML"
scope as everything else here, just one more dictionary.

Two ways to run it:
- **Programmatically**: `from chatbot import simple_chatbot; simple_chatbot("What is Tesla's total revenue?")`
- **Interactively**: `python chatbot.py` starts a command-line loop using `input()`, as suggested in the task brief.

## Predefined queries it can answer

| # | Query type | Example phrasing | Data field used |
|---|---|---|---|
| 1 | Total revenue | "What is the total revenue?" / "What is Tesla's total revenue in 2023?" | `Total Revenue` |
| 2 | Net income (plain) | "What is Apple's net income?" | `Net Income` |
| 3 | Net income year-over-year change | "How has net income changed over the last year?" | `Net Income` (current vs. prior year) |
| 4 | Total assets | "What are the total assets?" | `Total Assets` |
| 5 | Total liabilities | "What are Apple's total liabilities?" | `Total Liabilities` |
| 6 | Operating cash flow | "What is the operating cash flow?" | `Operating Cash Flow` |

Any query that doesn't match one of these falls through to the `else` branch and
returns a message listing what the bot can actually answer, rather than a generic
"I don't understand."

## Test results

See `test_results.txt` for the full output of an 11-query test run covering every
query type above across all three companies, plus one deliberately out-of-scope
query ("What is the weather today?") to confirm the fallback branch fires correctly.
All responses were checked by hand against the Task 1 dataset and are correct —
for example, Tesla's net income decline of 46.5% in FY2025 matches the $7,091M →
$3,794M figures from Task 1.

## Limitations

- **Keyword matching, not real language understanding.** The bot looks for literal
  substrings ("revenue", "net income", company names, four-digit years). Phrasing
  it hasn't been built to recognize — synonyms, typos, indirect questions like
  "how much money did Apple make" — will fall through to the fallback response even
  though a human would understand the intent.
- **Ambiguous defaults, not clarifying questions.** If the user doesn't name a
  company, the bot silently assumes Microsoft rather than asking which company they
  meant. This keeps the prototype simple but means an underspecified query never
  gets clarified — it gets guessed, and the guess is disclosed in the response text
  rather than confirmed with the user first.
- **Fixed data window.** Only FY2023–FY2025 for Microsoft, Tesla, and Apple are
  available, because that's what Task 1 extracted. Any question outside that scope
  (other companies, other years, quarterly data, non-financial questions) returns
  the same generic fallback message regardless of why it failed to match.
- **No compound queries.** "Compare Apple and Tesla's revenue" or "What was net
  income and revenue for Microsoft" aren't supported — each query is matched to
  exactly one response type.
- **No error handling for malformed data.** If `financial_data.csv` were corrupted
  or missing required columns, the script would raise a `KeyError` rather than
  failing gracefully. Acceptable for a prototype; would need to be addressed before
  any real-world use.
